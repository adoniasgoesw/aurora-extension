# Aurora MidJourney

Extensão **Chrome (Manifest V3)** para **midjourney.com**. Focada num fluxo **enxuto**: você lista **vários prompts (um por linha)** e a extensão **envia um de cada vez** para a barra **Imagine**, espera sinal de nova imagagem no feed e só então avança para o seguinte (com intervalo configurável). **Não** inclui download automático de ficheiros para o disco — apenas **automação de envio de prompts** no browser.

---

## O que faz

- Painel flutuante com **Shadow DOM** (estilo alinhado ao ecossistema Aurora / Meta).
- **Localiza** o campo Imagine e o botão de envio via lista de seletores (a UI do Midjourney pode mudar).
- **Remove limites artificiais** de `maxlength` no campo da página quando possível, para permitir prompts longos programaticamente.
- **Deteta** novas imagens no feed (heurística com `img` e URLs/CDN) antes de passar ao próximo prompt.
- **Popup** e **background** mínimos (abrir Midjourney, mensagens simples).

---

## Arquitetura

| Peça | Ficheiro | Função |
|------|-----------|--------|
| **Content script** | `content.js` | Painel, fila de prompts, escrita no Imagine, clique em enviar, espera por nova imagem, delays entre prompts. |
| **Service worker** | `background.js` | Ex.: abrir `midjourney.com/imagine` via mensagem do popup. |
| **Popup** | `popup.html`, `popup.js`, `popup.css` | Entrada rápida para o site. |
| **Manifest** | `manifest.json` | MV3, `activeTab`, `tabs`, hosts Midjourney, `web_accessible_resources` para ícones no painel. |
| **Ícones** | `icons/` | PNGs do manifest + recurso usado no painel. |

**Fluxo resumido:** utilizador clica **Iniciar** → para cada linha do textarea, o script foca o Imagine, injeta o texto, dispara eventos de input, espera o botão de envio e submete → aguarda aumento no número de imagens relevantes no DOM → pausa → próximo prompt.

---

## Stack técnica

- **JavaScript vanilla** (sem framework).
- **Manifest V3** — content script em `document_end` nos domínios Midjourney.
- **Shadow DOM** — isolamento de CSS do painel.
- **APIs:** `chrome.runtime`, `chrome.tabs` (conforme permissões), manipulação do DOM da página.

---

## Instalação (desenvolvimento)

1. `chrome://extensions` → **Modo do programador** → **Carregar sem compactação** → pasta `Aurora MidJourney`.
2. Abra [Midjourney Imagine](https://www.midjourney.com/imagine) (ou o URL atual da área de criação).
3. Use o painel para colar a fila de prompts e **Iniciar**.

---

## Permissões

- **`activeTab` / `tabs`** — abrir ou focar o site Midjourney a partir do popup/fluxo.
- **`host_permissions`** — apenas domínios Midjourney para o content script e recursos.

---

## Limitações

- Depende do **layout e dos seletores** do site; atualizações do Midjourney podem exigir ajustes em `CONFIG.inputSelectors`, `sendSelectors` e na deteção de imagens.
- **Sem download automático** integrado: o utilizador gere ficheiros pelo próprio Midjourney ou outras ferramentas.

---

## Distribuição

O projeto **Aurora Site** gera um **`.zip` ofuscado** desta pasta para download público. Para desenvolvimento, use sempre esta pasta em modo não compactado no Chrome.

---

## Relação com Aurora Meta

| | Aurora Meta | Aurora MidJourney (esta) |
|---|-------------|---------------------------|
| Alvo | Meta AI | Midjourney |
| Fila de prompts | Sim | Sim |
| Download automático de imagens | Sim (`chrome.downloads`) | Não |
