# Aurora Meta

Extensão **Chrome (Manifest V3)** para **Meta AI** (`meta.ai` / `www.meta.ai`). Oferece um **painel flutuante** na página: você coloca **vários prompts (um por linha)** e a extensão **envia cada um em fila**, acompanha a geração e **dispara o download automático** das imagens geradas para a pasta de downloads do Chrome, com nomes organizados.

---

## O que faz

- **Enviar prompts em lote** — fila com pausa configurável entre um prompt e o próximo após concluir o ciclo anterior.
- **Automatizar download das imagens** — usa a API `chrome.downloads` no service worker para guardar os ficheiros quando as URLs estão disponíveis.
- **Painel na página** — UI isolada com **Shadow DOM** para não conflitar com o CSS do site da Meta.
- **Abas e filas** — visão principal (prompts + progresso) e visão de filas/retries conforme implementado em `content.js`.

Não substitui a conta nem os limites da Meta AI; apenas automatiza o browser dentro do que a página já permite.

---

## Arquitetura

| Peça | Ficheiro | Função |
|------|-----------|--------|
| **Content script** | `content.js` | Injeta o host + shadow root, UI, DOM da Meta (composer, imagens), orquestração da fila, mensagens para o background. |
| **Service worker** | `background.js` | Escuta pedidos de download (`DOWNLOAD_URL`), chama `chrome.downloads.download`. |
| **Popup** | `popup.html`, `popup.js`, `popup.css` | Atalho / branding ao clicar no ícone da extensão. |
| **Manifest** | `manifest.json` | MV3, permissão `downloads`, `host_permissions` para Meta + CDN de imagens. |
| **Assets** | `assets/` | Ícones, logos referenciados no manifest e no painel. |

**Fluxo resumido:** o utilizador cola prompts → **Iniciar** → o content script preenche o composer da Meta, submete, espera as imagens aparecerem no DOM, extrai URLs e pede ao background para baixar. Erros e timeouts são tratados na lógica da fila.

---

## Stack técnica

- **JavaScript vanilla** (sem React na extensão).
- **Chrome Extensions Manifest V3** — `content_scripts` + `background.service_worker`.
- **Shadow DOM** — estilos e markup do painel encapsulados.
- **APIs:** `chrome.runtime`, `chrome.downloads`, DOM da página Meta (seletores podem precisar de manutenção se a Meta alterar o layout).

---

## Instalação (desenvolvimento)

1. Abra `chrome://extensions`.
2. Ative **Modo do programador**.
3. **Carregar sem compactação** e escolha esta pasta `Aurora Meta`.
4. Abra [Meta AI](https://www.meta.ai) num separador; o painel deve aparecer (se o content script corresponder aos URLs do manifest).

---

## Permissões

- **`downloads`** — necessária para gravar imagens no disco.
- **`host_permissions`** — `meta.ai` e `*.fbcdn.net` (e variantes) para scripts e pedidos de rede relacionados com a origem das imagens.

---

## Manutenção

A UI da Meta muda com frequência. Se deixar de enviar prompts ou de detetar imagens, atualize os seletores e tempos de espera em `content.js`. O repositório **Aurora Site** inclui um script que **ofusca** este código ao gerar o `.zip` para distribuição; o código aqui mantém-se legível para desenvolvimento.

---

## Relação com Aurora MidJourney

**Aurora Meta** = prompts **+** download automático de imagens.  
**Aurora MidJourney** = apenas envio de prompts em lote no site Midjourney, sem camada de download na extensão.
