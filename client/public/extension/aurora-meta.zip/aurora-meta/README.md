# Aurora Meta

Extensão **Chrome (Manifest V3)** para **Meta AI** (`meta.ai` / `www.meta.ai`). Oferece um **painel flutuante** na página: você coloca **vários prompts (um por linha)** e a extensão **envia cada um em fila**, acompanha a geração e **dispara o download automático** das imagens geradas para a pasta de downloads do Chrome, com nomes organizados.

---

## O que faz

- **Enviar prompts em lote** — fila com pausa configurável entre um prompt e o próximo após concluir o ciclo anterior.
- **Automatizar download das imagens** — usa a API `chrome.downloads` no service worker para guardar os ficheiros quando as URLs estão disponíveis.
- **Painel na página** — UI isolada com **Shadow DOM** para não conflitar com o CSS do site da Meta.
- **Abas e filas** — visão principal (prompts + progresso) e visão de filas/retries conforme implementado em `content.js`.

Não substitui a conta nem os limites da Meta AI; apenas automatiza o browser dentro do que a página já permite.

---

## Arquitetura

| Peça | Ficheiro | Função |
|------|-----------|--------|
| **Content script** | `content.js` | Injeta o host + shadow root, UI, DOM da Meta (composer, imagens), orquestração da fila, mensagens para o background. |
| **Service worker** | `background.js` | Escuta pedidos de download (`DOWNLOAD_URL`), chama `chrome.downloads.download`. |
| **Popup** | `popup.html`, `popup.js`, `popup.css` | Atalho / branding ao clicar no ícone da extensão. |
| **Manifest** | `manifest.json` | MV3, permissão `downloads`, `host_permissions` para Meta + CDN de imagens. |
| **Assets** | `assets/` | Ícones, logos referenciados no manifest e no painel. |

**Fluxo resumido:** o utilizador cola prompts → **Iniciar** → o content script preenche o composer da Meta, submete, espera as imagens aparecerem no DOM, extrai URLs e pede ao background para baixar. Erros e timeouts são tratados na lógica da fila.

---

## Stack técnica

Tecnologias usadas para construir a extensão (sem framework front-end na própria extensão):

| Área | O que foi usado |
|------|-----------------|
| **Linguagem** | **JavaScript (ES6+)** puro — um único bundle lógico por ficheiro, sem TypeScript nem bundler na pasta da extensão. |
| **Plataforma** | **Chrome Extensions Manifest V3** — modelo atual do Chrome: `manifest.json` declara permissões, hosts e ficheiros. |
| **Script na página** | **`content_scripts`** — `content.js` corre no contexto da página Meta (`run_at: document_idle`), com acesso ao DOM para composer, imagens e fila. |
| **Processo em segundo plano** | **`background.service_worker`** — `background.js` como service worker (sem página persistente); ideal para `chrome.downloads` e mensagens. |
| **UI do painel** | **Shadow DOM (`attachShadow`)** — o painel vive num shadow root ligado a um host no `documentElement`; CSS e HTML ficam isolados do site da Meta. |
| **Popup do ícone** | **HTML + CSS + JS clássicos** — `popup.html` / `popup.js` / `popup.css` (página de extensão, não é content script). |
| **Comunicação** | **`chrome.runtime.sendMessage` / `onMessage`** — o content script pede downloads ao service worker; `return true` para respostas assíncronas. |
| **APIs Chrome** | **`chrome.runtime`** (IDs, `getURL`, mensagens), **`chrome.downloads`** (gravar imagens com `filename` organizado). |
| **Recursos estáticos** | **`web_accessible_resources`** — por exemplo `assets/logo2.png` exposto aos domínios Meta para a `<img>` do painel carregar via `chrome.runtime.getURL(...)`. |
| **Integração web** | **DOM APIs + eventos sintéticos** — preenchimento do composer, cliques, `InputEvent` / `KeyboardEvent` onde a UI da Meta é reativa. |

**Resumo:** extensão **100% vanilla JS** sobre **MV3**, com **Shadow DOM** para o painel, **service worker** para downloads e **host permissions** alinhadas ao Meta AI e CDN de imagens.

---

## Instalação (desenvolvimento)

1. Abra `chrome://extensions`.
2. Ative **Modo do programador**.
3. **Carregar sem compactação** e escolha esta pasta `Aurora Meta`.
4. Abra [Meta AI](https://www.meta.ai) num separador; o painel deve aparecer (se o content script corresponder aos URLs do manifest).

---

## Permissões

- **`downloads`** — necessária para gravar imagens no disco.
- **`host_permissions`** — `meta.ai` e `*.fbcdn.net` (e variantes) para scripts e pedidos de rede relacionados com a origem das imagens.

---

## Manutenção

A UI da Meta muda com frequência. Se deixar de enviar prompts ou de detetar imagens, atualize os seletores e tempos de espera em `content.js`. O repositório **Aurora Site** inclui um script que **ofusca** este código ao gerar o `.zip` para distribuição; o código aqui mantém-se legível para desenvolvimento.

---

## Relação com Aurora MidJourney

**Aurora Meta** = prompts **+** download automático de imagens.  
**Aurora MidJourney** = apenas envio de prompts em lote no site Midjourney, sem camada de download na extensão.
